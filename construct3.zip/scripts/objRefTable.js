const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.iframe,
		C3.Plugins.Browser,
		C3.Plugins.Mouse,
		C3.Plugins.Touch,
		C3.Plugins.Keyboard,
		C3.Plugins.gamepad,
		C3.Plugins.Text,
		C3.Plugins.TextBox,
		C3.Plugins.Button,
		C3.Plugins.Sprite,
		C3.Plugins.iframe.Cnds.IsVisible,
		C3.Plugins.iframe.Acts.NavigateURL,
		C3.Plugins.TextBox.Exps.Text,
		C3.Plugins.Sprite.Cnds.IsVisible,
		C3.Plugins.Sprite.Acts.SetX,
		C3.Plugins.Mouse.Exps.X,
		C3.Plugins.Sprite.Acts.SetY,
		C3.Plugins.Mouse.Exps.Y
	];
};
self.C3_JsPropNameTable = [
	{CNET3: 0},
	{Navegador: 0},
	{Mouse: 0},
	{Toque: 0},
	{Teclado: 0},
	{Gamepad: 0},
	{Texto: 0},
	{link: 0},
	{Botão: 0},
	{Texto2: 0},
	{Sprite: 0}
];

self.InstanceType = {
	CNET3: class extends self.IIframeInstance {},
	Navegador: class extends self.IInstance {},
	Mouse: class extends self.IInstance {},
	Toque: class extends self.IInstance {},
	Teclado: class extends self.IInstance {},
	Gamepad: class extends self.IInstance {},
	Texto: class extends self.ITextInstance {},
	link: class extends self.ITextInputInstance {},
	Botão: class extends self.IButtonInstance {},
	Texto2: class extends self.ITextInstance {},
	Sprite: class extends self.ISpriteInstance {}
}